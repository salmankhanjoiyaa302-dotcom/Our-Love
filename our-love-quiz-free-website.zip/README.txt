OUR LOVE QUIZ — FREE WEBSITE

Files:
- index.html: complete self-contained website (HTML/CSS/JavaScript). No paid libraries or build tools.

Try it:
1. Open index.html in a browser.
2. Tap Start Our Quiz and answer the questions.
3. The result and answers are saved in that browser's local storage.

Important limitation:
This static version does NOT transmit answers from your girlfriend's phone to your device. The Admin page only displays responses saved in the same browser. The demo admin PIN is 2468 and is NOT secure; change it in index.html before using it, and do not treat it as real authentication.

Free hosting with GitHub Pages:
1. Sign in or create a free account at https://github.com
2. Create a new public repository, e.g. our-love-quiz
3. Upload index.html to the repository's root.
4. Open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
6. Wait for the published URL shown in Settings → Pages, then send that link.

To receive responses from another device:
Connect a backend such as Firebase/Supabase free tier or a Google Apps Script web app. Do not collect sensitive personal information, and don't rely on a client-side PIN for privacy.
